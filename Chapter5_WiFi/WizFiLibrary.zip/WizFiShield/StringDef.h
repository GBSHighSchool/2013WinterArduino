#ifndef _STRINGDEF_H_
#define _STRINGDEF_H_

#include "Config.h"


#endif
